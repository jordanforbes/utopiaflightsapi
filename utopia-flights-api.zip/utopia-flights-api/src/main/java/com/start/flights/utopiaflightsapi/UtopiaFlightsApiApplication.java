package com.start.flights.utopiaflightsapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UtopiaFlightsApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(UtopiaFlightsApiApplication.class, args);
	}

}
