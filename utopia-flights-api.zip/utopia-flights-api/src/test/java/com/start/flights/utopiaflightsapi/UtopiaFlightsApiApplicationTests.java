package com.start.flights.utopiaflightsapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UtopiaFlightsApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
